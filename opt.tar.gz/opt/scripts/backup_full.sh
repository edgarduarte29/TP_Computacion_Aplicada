#!/bin/bash
#
# backup_full.sh
# Uso: backup_full.sh -o ORIGEN -d DESTINO
#        backup_full.sh -help

PROG=$(basename "$0")
DATE=$(date +%Y%m%d)

print_help() {
  cat << EOF
Usage: $PROG -o ORIGEN -d DESTINO
Opciones:
  -o, --origen     Directorio o archivo a respaldar (obligatorio)
  -d, --destino    Directorio de destino (obligatorio; monta /backup_dir)
  -h, --help       Mostrar esta ayuda
EOF
}

# Parseo de argumentos
ORIGEN=""
DESTINO=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    -o|--origen)
      ORIGEN="$2"; shift 2;;
    -d|--destino)
      DESTINO="$2"; shift 2;;
    -h|--help)
      print_help; exit 0;;
    *)
      echo "Error: opción desconocida: $1" >&2
      print_help; exit 1;;
  esac
done

# Validar parámetros
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
  echo "Error: faltan argumentos obligatorios." >&2
  print_help
  exit 1
fi

# Validar que exista el directorio de origen
if [[ ! -e "$ORIGEN" ]]; then
  echo "Error: el directorio de ORIGEN no existe: $ORIGEN" >&2
  exit 2
fi


# Validar que exista destino
if ! mountpoint -q "$DESTINO"; then
  echo "Error: el directorio DESTINO no está montado." >&2
  exit 3
fi

# Formar nombre de archivo
BASE=$(basename "$ORIGEN")
ARCH="${BASE}_bkp_${DATE}.tar.gz"
RUTA="$DESTINO/$ARCH"

# Ejecutar backup
echo "[$(date '+%F %T')] Iniciando backup de '$ORIGEN' en '$RUTA'..."
tar czf "$RUTA" -C "$(dirname "$ORIGEN")" "$BASE"
RC=$?

if [[ $RC -eq 0 ]]; then
  echo "[$(date '+%F %T')] Backup completado: $RUTA"
else
  echo "[$(date '+%F %T')] Error al crear backup (código $RC)" >&2
fi

exit $RC

