<?php
  echo "<h1>¡Bienvenido al trabajo del Grupo 6!</h1>";
  echo "<p>servidor apache desde /www_dir, actividad grupal</p>";
?>
